import React, { useMemo, useState } from 'react';

const feelings = [
  'Sad',
  'Anxious',
  'Angry',
  'Overwhelmed',
  'Lonely',
  'Tired',
  'Hopeless',
  'Just need encouragement',
];

const ageRanges = ['Under 18', '18–25', '26–40', '41–60', '60+'];

const smallSteps = [
  'Let’s pause together for a moment. Take 3 slow breaths — in… and out…',
  'Drink a glass of water and let your body know it is safe to soften a little.',
  'Step outside for fresh air, even for just a minute.',
  'Write one honest sentence about how you feel right now.',
  'Stretch your body gently for 2 minutes.',
  'Text someone you trust and say, “I just need a little encouragement today.”',
  'Listen to calming music for 5 minutes and let yourself breathe.',
  'Rest without guilt for a few minutes. You do not have to earn rest.',
];

const strengthWords = {
  Courage: 'Courage is not the absence of fear. It is choosing to keep going even when your heart feels heavy.',
  Hope: 'Hope is a quiet light. Even a small light can guide you through a dark moment.',
  Peace: 'Peace begins in one small pause, one breath, one gentle decision to be kind to yourself.',
  Strength: 'Strength is not always loud. Sometimes it is simply staying, breathing, and trying again.',
  Healing: 'Healing is not a race. Every small step still counts.',
  Resilience: 'Resilience is the soft but steady power that helps you rise again.',
  Patience: 'Patience is allowing your heart room to recover without forcing it.',
  Faith: 'Faith is trusting that your life still carries meaning, even when the road feels unclear.',
};

const library = {
  Anxiety: 'You do not have to solve everything today. Let this moment be small enough to breathe through.',
  Loneliness: 'Your life still has meaning, even on days when connection feels far away.',
  'Self-worth': 'You are worthy of care, gentleness, and respect — even on your hardest days.',
  Healing: 'Healing often begins quietly, with one honest breath and one kind decision.',
  Confidence: 'You do not need to feel fearless to take the next step.',
  Strength: 'You have already survived days you once thought would break you.',
  'Starting again': 'Beginning again is not failure. It is courage in motion.',
};

function getStrengthWord() {
  const keys = Object.keys(strengthWords);
  return keys[new Date().getDate() % keys.length];
}

function getSmallStep(seed = 0) {
  return smallSteps[seed % smallSteps.length];
}

function containsCrisisText(text) {
  const lower = (text || '').toLowerCase();
  return [
    'i want to die',
    'kill myself',
    'end my life',
    'hurt myself',
    'suicide',
    'self harm',
  ].some((phrase) => lower.includes(phrase));
}

function buildMessage({ name, feeling, challenge, faithMode }) {
  const userName = name?.trim() || 'Friend';

  const base = {
    Sad: `${userName}, thank you for sharing this with me. I’m really glad you didn’t keep it inside. Sadness can feel heavy, like everything is slower and harder than it should be. But nothing about this feeling takes away who you are. You are still valuable, still needed, still enough.`,
    Anxious: `${userName}, I’m really glad you came here. I can feel how restless things might be for you right now. Anxiety makes everything feel urgent, like you must fix everything at once. But you don’t. You are allowed to slow down. You are allowed to breathe.`,
    Angry: `${userName}, it’s okay to feel this anger. Strong emotions often come from something that matters deeply to you. There may be hurt underneath, or something that feels unfair.`,
    Overwhelmed: `${userName}, I can feel how much you’re carrying right now. When everything comes at once, it can feel like too much. But you don’t have to solve everything today.`,
    Lonely: `${userName}, I hear you. Loneliness can feel very deep, like you are unseen. But your presence still matters more than you know.`,
    Tired: `${userName}, it sounds like you’ve been carrying a lot for a long time. This kind of tiredness is not just physical, it’s deep.`,
    Hopeless: `${userName}, I’m really grateful you came here. I know it’s not easy to reach out when everything feels heavy.`,
    'Just need encouragement': `${userName}, I’m really glad you came here today. Reaching for encouragement takes strength.`,
  };

  const middle = {
    Sad: 'You do not have to rush out of this feeling. Just sit gently with yourself for a moment.',
    Anxious: 'Nothing is chasing you in this moment. You are safe to slow down.',
    Angry: 'Take a moment before reacting, not to ignore your feelings, but to protect your peace.',
    Overwhelmed: 'Let’s make things smaller. Just this moment. Just this breath.',
    Lonely: 'Even if connection feels far right now, it is not gone forever.',
    Tired: 'You do not have to push through everything today. Rest is part of healing.',
    Hopeless: 'This moment is not the end of your story. Something in you is still holding on.',
    'Just need encouragement': 'You are still showing up, still trying, and that matters.',
  };

  const endings = [
    'You are not invisible.',
    'You matter — even now.',
    'This moment is not your whole story.',
    'You are still becoming.',
  ];

  const ending = endings[(userName.length + (challenge?.length || 0)) % endings.length];
  const challengeLine = challenge?.trim() ? ` What you shared matters: “${challenge.trim()}”.` : '';
  const faithLine = faithMode ? ' Even when you cannot see the road ahead, your life still carries purpose.' : '';

  return `${base[feeling] || base['Just need encouragement']}${challengeLine} ${middle[feeling] || middle['Just need encouragement']} Even now, ${userName}, there is still strength in you, even if it feels quiet.${faithLine} ${ending}`;
}

export default function App() {
  const [screen, setScreen] = useState('welcome');
  const [name, setName] = useState('');
  const [feeling, setFeeling] = useState('');
  const [challenge, setChallenge] = useState('');
  const [ageRange, setAgeRange] = useState('');
  const [faithMode, setFaithMode] = useState(false);
  const [mood, setMood] = useState('');
  const [history, setHistory] = useState([]);
  const [messageVersion, setMessageVersion] = useState(0);

  const strengthWord = useMemo(() => getStrengthWord(), []);
  const encouragement = useMemo(
    () => buildMessage({ name, feeling, challenge, faithMode }),
    [name, feeling, challenge, faithMode, messageVersion]
  );
  const smallStep = useMemo(() => getSmallStep((name.length + challenge.length + messageVersion) || 0), [name, challenge, messageVersion]);

  const submitForm = () => {
    if (containsCrisisText(challenge)) {
      setScreen('emergency');
      return;
    }
    if (!feeling) return;
    setScreen('response');
  };

  const saveMood = (selectedMood) => {
    setMood(selectedMood);
    const today = new Date().toLocaleDateString();
    setHistory((prev) => [{ mood: selectedMood, date: today }, ...prev].slice(0, 7));
  };

  const speakMessage = () => {
    if (!('speechSynthesis' in window)) return;
    const utterance = new SpeechSynthesisUtterance(`${encouragement} Small step for today: ${smallStep}`);
    utterance.rate = 0.92;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="app-shell">
      <div className="container">
        <header className="topbar card">
          <div>
            <h1>Seen &amp; Strong</h1>
            <p>You are seen. You are heard. You are stronger than this moment.</p>
          </div>
          <label className="faith-toggle">
            <span>Faith Mode</span>
            <input type="checkbox" checked={faithMode} onChange={(e) => setFaithMode(e.target.checked)} />
          </label>
        </header>

        <section className="top-grid">
          <div className="card strength-card">
            <div className="eyebrow">Today’s Strength Word</div>
            <h2>{strengthWord}</h2>
            <p>{strengthWords[strengthWord]}</p>
          </div>
          <div className="card mood-card">
            <div className="eyebrow">Daily Mood</div>
            <div className="mood-row">
              {['😊', '🙂', '😐', '😔', '😞'].map((emoji) => (
                <button
                  key={emoji}
                  className={mood === emoji ? 'mood active' : 'mood'}
                  onClick={() => saveMood(emoji)}
                >
                  {emoji}
                </button>
              ))}
            </div>
            <small>Weekly check-ins: {history.length}</small>
          </div>
        </section>

        {screen === 'welcome' && (
          <main className="card hero">
            <div className="hero-icon">❤</div>
            <h2>Welcome to Seen &amp; Strong</h2>
            <p>
              This is a safe place for encouragement and hope. You are not invisible. You are not alone.
              Take a moment and share what you are going through.
            </p>
            <button className="primary-btn" onClick={() => setScreen('input')}>Start</button>
          </main>
        )}

        {screen === 'input' && (
          <main className="card form-card">
            <div className="section-head">
              <button className="ghost-btn" onClick={() => setScreen('welcome')}>←</button>
              <h2>How are you feeling today?</h2>
            </div>

            <div className="field-grid">
              <label>
                <span>Name</span>
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Michael" />
              </label>

              <label>
                <span>How do you feel today?</span>
                <select value={feeling} onChange={(e) => setFeeling(e.target.value)}>
                  <option value="">Select a feeling</option>
                  {feelings.map((item) => <option key={item} value={item}>{item}</option>)}
                </select>
              </label>
            </div>

            <label>
              <span>What challenge are you facing today?</span>
              <textarea
                value={challenge}
                onChange={(e) => setChallenge(e.target.value)}
                placeholder="I feel like I keep failing in life."
              />
            </label>

            <label>
              <span>Optional: Age range</span>
              <select value={ageRange} onChange={(e) => setAgeRange(e.target.value)}>
                <option value="">Choose an age range</option>
                {ageRanges.map((item) => <option key={item} value={item}>{item}</option>)}
              </select>
            </label>

            <button className="primary-btn" onClick={submitForm} disabled={!feeling}>Encourage Me</button>
          </main>
        )}

        {screen === 'response' && (
          <main className="response-stack">
            <section className="card form-card">
              <div className="section-head between">
                <div className="section-head">
                  <button className="ghost-btn" onClick={() => setScreen('input')}>←</button>
                  <h2>Your Encouragement</h2>
                </div>
                <button className="secondary-btn" onClick={speakMessage}>Read Message Aloud</button>
              </div>

              <div className="soft-panel">
                <p>{encouragement}</p>
              </div>

              <div className="soft-panel">
                <div className="eyebrow">Small Step for Today</div>
                <p>{smallStep}</p>
              </div>

              <div className="button-row">
                <button className="primary-btn" onClick={() => setMessageVersion((v) => v + 1)}>Another Message</button>
                <button className="secondary-btn" onClick={() => setScreen('library')}>Encouragement Library</button>
              </div>
            </section>
          </main>
        )}

        {screen === 'library' && (
          <main className="card form-card">
            <div className="section-head">
              <button className="ghost-btn" onClick={() => setScreen('response')}>←</button>
              <h2>Encouragement Library</h2>
            </div>
            <div className="library-grid">
              {Object.entries(library).map(([title, text]) => (
                <article className="mini-card" key={title}>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </article>
              ))}
            </div>
          </main>
        )}

        {screen === 'emergency' && (
          <main className="card emergency-card">
            <h2>Please reach out for immediate support</h2>
            <p>
              I’m really sorry that you are hurting this deeply. You deserve immediate support from a real person who can help you through this moment.
            </p>
            <div className="support-grid">
              <div className="mini-card">
                <h3>Samaritans</h3>
                <p>Call 116 123</p>
              </div>
              <div className="mini-card">
                <h3>NHS 111</h3>
                <p>Call 111</p>
              </div>
              <div className="mini-card">
                <h3>Emergency services</h3>
                <p>Call 999</p>
              </div>
            </div>
            <button className="primary-btn" onClick={() => setScreen('welcome')}>Return to Welcome</button>
          </main>
        )}

        <footer className="footer-note">
          Seen &amp; Strong provides encouragement and emotional support. It is not a medical or therapy service.
        </footer>
      </div>
    </div>
  );
}
