import React, { useState } from 'react'

const steps = [
  "Take 3 slow breaths.",
  "Drink a glass of water.",
  "Step outside for fresh air.",
  "Rest for a few minutes."
]

function getMessage(name, feeling) {
  const user = name || "Friend"
  const base = {
    Sad: `${user}, thank you for sharing this with me. Sadness can feel heavy, but you are still worthy. This moment is not your whole story.`,
    Anxious: `${user}, I’m really glad you came here. Anxiety can feel overwhelming, but you are safe to slow down and breathe.`,
    Lonely: `${user}, I hear you. You are not invisible. Your presence still matters.`,
    Overwhelmed: `${user}, I can feel how much you’re carrying. You don’t have to solve everything today.`,
    Hopeless: `${user}, I’m really grateful you came here. This moment is not the end of your story.`
  }
  return base[feeling] || `${user}, I’m glad you are here. You matter more than you know.`
}

export default function App() {
  const [screen, setScreen] = useState("welcome")
  const [name, setName] = useState("")
  const [feeling, setFeeling] = useState("")

  const message = getMessage(name, feeling)
  const step = steps[Math.floor(Math.random()*steps.length)]

  if (screen === "welcome") {
    return (
      <div style={{padding:20}}>
        <h1>Seen & Strong</h1>
        <p>You are seen. You are heard. You are stronger than this moment.</p>
        <button onClick={() => setScreen("input")}>Start</button>
      </div>
    )
  }

  if (screen === "input") {
    return (
      <div style={{padding:20}}>
        <h2>How do you feel?</h2>
        <input placeholder="Your name" value={name} onChange={e=>setName(e.target.value)} />
        <br/><br/>
        <select value={feeling} onChange={e=>setFeeling(e.target.value)}>
          <option value="">Select feeling</option>
          <option>Sad</option>
          <option>Anxious</option>
          <option>Lonely</option>
          <option>Overwhelmed</option>
          <option>Hopeless</option>
        </select>
        <br/><br/>
        <button onClick={()=>setScreen("result")}>Encourage Me</button>
      </div>
    )
  }

  if (screen === "result") {
    return (
      <div style={{padding:20}}>
        <h2>Your Message</h2>
        <p>{message}</p>
        <h3>Small Step</h3>
        <p>{step}</p>
        <button onClick={()=>setScreen("input")}>Another Message</button>
      </div>
    )
  }

  return null
}
